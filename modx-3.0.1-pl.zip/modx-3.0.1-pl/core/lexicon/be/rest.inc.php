<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Памылка!';
$_lang['rest.err_class_remove'] = 'An error occurred while trying to delete the [[+class_key]]';
$_lang['rest.err_class_save'] = 'Адбылася памылка пры спробе захаваць [[+class_key]]';
$_lang['rest.err_field_ns'] = 'Поле [[+field]] не пазначана!';
$_lang['rest.err_field_required'] = 'Гэта поле абавязковае.';
$_lang['rest.err_fields_required'] = 'Наступныя палі з\'яўляюцца абавязковымі: [[+fields]]';
$_lang['rest.err_obj_nf'] = 'Аб\'ект класа [[+class_key]] не знойдзены!';
